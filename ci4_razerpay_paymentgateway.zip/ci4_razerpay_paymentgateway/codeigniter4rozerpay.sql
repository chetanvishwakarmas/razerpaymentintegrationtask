-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 13, 2024 at 07:27 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `codeigniter4rozerpay`
--

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `payment_amount` float(8,2) NOT NULL,
  `payment_status` tinyint(4) NOT NULL COMMENT '1:success 0:failure',
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`id`, `customer_name`, `transaction_id`, `payment_amount`, `payment_status`, `transaction_date`, `created_at`, `updated_at`) VALUES
(1, 'ram', '10200405060001', 100.00, 1, '2024-11-12 09:38:15', '2024-11-12 10:35:16', '2024-11-12 10:35:16'),
(2, 'shyam', '10200405060002', 200.00, 1, '2024-11-12 09:38:15', '2024-11-12 10:35:16', '2024-11-12 10:35:16'),
(3, 'suresh', '10200405060003', 100.00, 0, '2024-11-12 09:38:15', '2024-11-12 10:35:16', '2024-11-12 10:35:16'),
(4, 'kamlesh', '10200405060004', 200.00, 1, '2024-11-12 09:38:15', '2024-11-12 10:35:16', '2024-11-12 10:35:16'),
(5, 'faran', '10200405060005', 100.00, 1, '2024-11-12 09:38:15', '2024-11-12 10:35:16', '2024-11-12 10:35:16'),
(6, 'deepak', '10200405060006', 200.00, 0, '2024-11-12 09:38:15', '2024-11-12 10:35:16', '2024-11-12 10:35:16'),
(7, 'kamal', '10200405060007', 100.00, 1, '2024-11-12 09:38:15', '2024-11-12 10:35:16', '2024-11-12 10:35:16'),
(8, 'kamlesh', '10200405060008', 200.00, 1, '2024-11-12 09:38:15', '2024-11-12 10:35:16', '2024-11-12 10:35:16'),
(9, 'sdfsdf', 'OId44', 10.00, 0, '2024-11-12 23:59:14', '2024-11-12 23:59:14', '2024-11-12 23:59:14'),
(10, 'testcustomer', 'OId12', 10.00, 1, '2024-11-13 00:00:39', '2024-11-13 00:00:39', '2024-11-13 00:00:39'),
(11, 'sdfsdf', 'OId62', 10.00, 0, '2024-11-13 00:04:09', '2024-11-13 00:04:09', '2024-11-13 00:04:09'),
(12, 'testcustomer', 'OId95', 1000.00, 0, '2024-11-13 00:51:56', '2024-11-13 00:51:56', '2024-11-13 00:51:56'),
(13, 'testcustomer', 'OId43', 1001.00, 0, '2024-11-13 00:52:20', '2024-11-13 00:52:20', '2024-11-13 00:52:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
