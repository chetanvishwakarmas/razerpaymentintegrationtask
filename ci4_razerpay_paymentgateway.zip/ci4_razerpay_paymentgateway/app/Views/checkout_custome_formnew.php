<!DOCTYPE html>
<html>
<head>
  <title>Razorpay payment gateway custome form </title>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" media="screen">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body style="background-repeat: no-repeat;">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <form action="<?php echo base_url('checkoutcustomeformnew/paynow'); ?>" method="post" >
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">Charge Rs.10 INR  </h4>
                    </div>
                    <div class="panel-body">
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control" name="billing_name" id="billing_name" placeholder="Enter name" required="" autofocus="">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control" name="billing_email" id="billing_email" placeholder="Enter email" required="">
                        </div>
                        <div class="form-group">
                            <label>Mobile Number</label>
                            <input type="number" class="form-control" name="billing_mobile" id="billing_mobile" min-length="10" max-length="10" placeholder="Enter Mobile Number" required="" autofocus="">
                        </div>                        
                        <div class="form-group">
                            <label>Payment Amount</label>
                            <input type="text" class="form-control" name="payAmount" id="payAmount" value="10" placeholder="Enter Amount" required="" autofocus="">
                        </div>
                        <div class="form-group">                            
                            <input type="radio" id="case_on_delivery" name="paymentType" value="case_on_delivery"  checked >
                            <label for="html">Cash On Delivery</label><br>                            
                            <input type="radio" id="razerpay" name="paymentType" value="razerpay">
                            <label for="html">RazerPay</label><br>               
                        </div>
                        <!-- submit button -->
                        <button type="submit" id="PayNow" class="btn btn-success btn-lg btn-block" >Submit & Pay</button>
                    </div>
                </div>
                </form>
            </div>            
        </div>
    </div>
</body>
</html>