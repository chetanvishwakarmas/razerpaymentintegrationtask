
<!DOCTYPE html>
<html>
<head>
    <title>Razorpay Payment Gateway</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    
    <nav class="navbar navbar-expand-sm bg-light">
      <div class="container-fluid">
        <ul class="navbar-nav">
          <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url(''); ?>">Home </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('checkoutsimple/checkout'); ?>">Pay now tab simple </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('checkoutcustomeform/checkout'); ?>">Pay now tab custome </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('checkoutcustomeformnew/checkout'); ?>">Pay now tab custome new </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('transaction'); ?>">Transactions </a>
          </li>
        </ul>
      </div>
    </nav>
    
    <div class="container">
        
        <form action="<?php echo base_url('checkoutcustomeform/paynow'); ?>" method="POST">
            <div class="mb-3 mt-3">
              <label for="text">Amount</label>
              <input type="text" class="form-control" id="amount" placeholder="Enter amount" name="amount" value="1" >
            </div>
            <div class="mb-3 mt-3">
              <label for="text">Name</label>
              <input type="text" class="form-control" id="name" placeholder="Enter name" name="name" value="chetan vishwakarma" >
            </div>
            <div class="mb-3 mt-3">
              <label for="text">Email</label>
              <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" value="chetanvishwakarma1908@gmail.com" >
            </div>
            <div class="mb-3 mt-3">
              <label for="text">Mobile</label>
              <input type="text" class="form-control" id="text" placeholder="Enter text" name="mobile" value="+919893532900">
            </div>
            <button type="submit" class="btn btn-primary" id="submit" name="submit" value="submit" >Submit</button>
        </form>
        
    </div>
    
</body>
</html>