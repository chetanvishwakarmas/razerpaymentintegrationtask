
<!DOCTYPE html>
<html>
<head>
    <title>Razorpay Payment Gateway</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

    <nav class="navbar navbar-expand-sm bg-light">
      <div class="container-fluid">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(''); ?>">Home </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('checkoutsimple/checkout'); ?>">Pay now tab simple </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('checkoutcustomeform/checkout'); ?>">Pay now tab custome </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('checkoutcustomeformnew/checkout'); ?>">Pay now tab custome new </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('transaction'); ?>">Transactions </a>
          </li>
        </ul>
      </div>
    </nav>

    <div class="container">
        <?php 
            $apiKey = "rzp_test_HSYmDqq745wqwZeXh48kg"; 
            $_POST['amount']=1;
            $_POST['name']='chetan vishwakarma';
            $_POST['email']='chetanvishwakarma1908@gmail.com';
            $_POST['mobile']='9893532900';
        ?>
        <div class="page-header">
            <h1>Pay with Razorpay</h1>
        </div>
        <div class="page-body">
            <form action="<?php base_url('checkoutsimple/success'); ?>" method="POST">
                <script src="https://checkout.razorpay.com/v1/checkout.js"
                    data-key="<?php echo $apiKey; ?>" 
                    data-amount="<?php $_POST['amount']*100; ?>" 
                    data-currency="INR"
                    data-id="<?php echo 'OID'.rand(10,100).'END'; ?>"
                    data-buttontext="Pay with Razorpay"
                    data-name="Test Data"
                    data-description="Testing details"
                    data-image="https://example.com/your_logo.jpg"
                    data-prefill.name="<?php echo $_POST['name']; ?>"
                    data-prefill.email="<?php echo $_POST['email']; ?>"
                    data-prefill.contact="<?php echo $_POST['mobile']; ?>"
                    data-theme.color="#F37254"
                ></script>
                <input type="hidden" custom="Hidden Element" name="hidden"/>
            </form>
        </div>
    </div>

</body>
</html>
