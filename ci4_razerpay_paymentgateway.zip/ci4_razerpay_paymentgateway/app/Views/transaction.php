<!DOCTYPE html>
<html lang="en">
<head>
  <title>Transaction Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    
    <nav class="navbar navbar-expand-sm bg-light">
      <div class="container-fluid">
        <ul class="navbar-nav">
          <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url(''); ?>">Home </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('checkoutsimple/checkout'); ?>">Pay now tab simple </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('checkoutcustomeform/checkout'); ?>">Pay now tab custome </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('checkoutcustomeformnew/checkout'); ?>">Pay now tab custome new </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('transaction'); ?>">Transactions </a>
          </li>
        </ul>
      </div>
    </nav>
    
    <div class="container mt-3">
      <h2>Transaction Page</h2>
      <p>transaction Page: </p>  
      <?php //print_r($transactionList); ?>
      <table class="table">
    <thead>
      <tr>
      	<th>Id </th>
        <th>Customer Name </th>
        <th>Transaction Id</th>
        <th>Payment Amount</th>
        <th>Payment Status</th>
        <th>Transaction Date</th>
        <th>Created At</th>
      </tr>
    </thead>
    <tbody>
      <?php 
      if(!empty($transactionList)){
	      foreach($transactionList as $transaction){ ?>
	      <tr>
	      	<td><?php echo $transaction['id']; ?></td>
	        <td><?php echo $transaction['customer_name']; ?></td>
	        <td><?php echo $transaction['transaction_id']; ?></td>
	        <td><?php echo $transaction['payment_amount']; ?></td>
	        <td><?php if($transaction['payment_status'] == 1){ echo "Success"; }else { echo "Failure"; } ?></td>
	        <td><?php echo $transaction_date = date("d-m-Y h:i:s a", strtotime($transaction['transaction_date']));
	        ?></td>
	        <td><?php echo $created_at = date("d-m-Y h:i:s a", strtotime($transaction['created_at'])); ?></td>
	      </tr>
	  	  <?php } ?>
      <?php } ?>
    </tbody>
      </table>
    </div>

</body>
</html>
