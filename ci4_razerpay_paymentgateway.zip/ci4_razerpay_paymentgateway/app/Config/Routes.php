<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'Home::index');

//CheckoutSimple
$routes->get('/checkoutsimple/checkout', 'CheckoutSimple::index');
$routes->post('/checkoutsimple/paynow', 'CheckoutSimple::paynow');
$routes->get('/checkoutsimple/success', 'CheckoutSimple::success');
$routes->get('/checkoutsimple/failure', 'CheckoutSimple::failure');

//CheckoutCustomeForm
$routes->get('/checkoutcustomeform/checkout', 'CheckoutCustomeForm::index');
$routes->post('/checkoutcustomeform/paynow', 'CheckoutCustomeForm::paynow');
$routes->get('/checkoutcustomeform/success', 'CheckoutCustomeForm::success');
$routes->get('/checkoutcustomeform/failure', 'CheckoutCustomeForm::failure');

//CheckoutCustomeFormNew
$routes->get('/checkoutcustomeformnew/checkout', 'CheckoutCustomeFormNew::index');
$routes->post('/checkoutcustomeformnew/paynow', 'CheckoutCustomeFormNew::paynow');
$routes->get('/checkoutcustomeformnew/success', 'CheckoutCustomeFormNew::success');
$routes->get('/checkoutcustomeformnew/failure', 'CheckoutCustomeFormNew::failure');

$routes->get('/transaction', 'Transaction::index');

$routes->get('/about', 'About::index');
$routes->get('/contact', 'Contact::index');
