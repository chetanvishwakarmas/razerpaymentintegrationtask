<?php

namespace App\Controllers;
use App\Models\TransactionModel;

class CheckoutCustomeFormNew extends BaseController {

	public function __construct(){
		//$this->session 	= \Config\Services::session();
	}
    
	public function index(){
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
        $data = array();
		echo view("checkout_custome_formnew", $data);
	}

    public function paynow(){
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
        
        $apiKey = "rzp_test_HSYmDqq745wqwZeXh48kg"; 
                
        $name = $_POST['billing_name'];
        $email = $_POST['billing_email'];
        $mobile = $_POST['billing_mobile'];
        $payAmount = $_POST['payAmount'];
        $paymentType = $_POST['paymentType'];
        
        if($paymentType == 'case_on_delivery'){
            $randomNumber = rand(999999999,10000000000);
            if($randomNumber%2==true){
                //success transaction entry
                echo "True";

                $TransactionModel = new TransactionModel();
                $data['customer_name'] = $name;
                $data['transaction_id'] = "OId".rand(1,100)."";
                $data['payment_amount'] = $payAmount;
                $data['payment_status'] = 1;
                $data['transaction_date'] = date("Y-m-d H:i:s");
                $TransactionModel->insert($data);

                return redirect()->route('transaction');

            }else {
                //failure transaction entry
                echo "False";            

                $TransactionModel = new TransactionModel();
                $data['customer_name'] = $name;
                $data['transaction_id'] = "OId".rand(1,100)."";
                $data['payment_amount'] = $payAmount;
                $data['payment_status'] = 0;
                $data['transaction_date'] = date("Y-m-d H:i:s");
                $TransactionModel->insert($data);

                return redirect()->route('transaction');

            } 
        }

        if($paymentType == 'razerpay'){
            header('Access-Control-Allow-Origin:*');
            header('Access-Control-Allow-Methods:POST,GET,PUT,PATCH,DELETE');
            header("Content-Type: application/json");
            header("Accept: application/json");
            header('Access-Control-Allow-Headers:Access-Control-Allow-Origin,Access-Control-Allow-Methods,Content-Type');
            
            if(isset($_POST['action']) && $_POST['action']='payOrder'){
                
                $razorpay_mode='test';
                 
                $razorpay_test_key='rzp_test_HSYmDqq745wqwZeXh48kg'; //Your Test Key
                $razorpay_test_secret_key='9pC05654yTBYyuyiuyiuyjPjKF3vNC3TZFXa'; //Your Test Secret Key
                 
                $razorpay_live_key= 'Your_Live_Key';
                $razorpay_live_secret_key='Your_Live_Secret_Key';
                 
                if($razorpay_mode=='test'){
                    $razorpay_key=$razorpay_test_key;
                    $authAPIkey="Basic ".base64_encode($razorpay_test_key.":".$razorpay_test_secret_key);
                }else{
                    $authAPIkey="Basic ".base64_encode($razorpay_live_key.":".$razorpay_live_secret_key);
                    $razorpay_key=$razorpay_live_key;
                }
                
                // Set transaction details
                $order_id = uniqid(); 
                 
                $billing_name=$_POST['billing_name'];
                $billing_mobile=$_POST['billing_mobile'];
                $billing_email=$_POST['billing_email'];
                $shipping_name=$_POST['shipping_name'];
                $shipping_mobile=$_POST['shipping_mobile'];
                $shipping_email=$_POST['shipping_email'];
                $paymentOption=$_POST['paymentOption'];
                $payAmount=$_POST['payAmount'];
                 
                $note="Payment of amount Rs. ".$payAmount;
                 
                $postdata=array(
                "amount"=>$payAmount*100,
                "currency"=> "INR",
                "receipt"=> $note,
                "notes" =>array(
                              "notes_key_1"=> $note,
                              "notes_key_2"=> ""
                              )
                );
                $curl = curl_init();
 
                curl_setopt_array($curl, array(
                  CURLOPT_URL => 'https://api.razorpay.com/v1/orders',
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => '',
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 0,
                  CURLOPT_FOLLOWLOCATION => true,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => 'POST',
                  CURLOPT_POSTFIELDS =>json_encode($postdata),
                  CURLOPT_HTTPHEADER => array(
                    'Content-Type: application/json',
                    'Authorization: '.$authAPIkey
                  ),
                ));
 
                $response = curl_exec($curl);
                 
                curl_close($curl);
                $orderRes= json_decode($response);
                 
                if(isset($orderRes->id)){
                 
                $rpay_order_id=$orderRes->id;
                 
                $dataArr=array(
                    'amount'=>$payAmount,
                    'description'=>"Pay bill of Rs. ".$payAmount,
                    'rpay_order_id'=>$rpay_order_id,
                    'name'=>$billing_name,
                    'email'=>$billing_email,
                    'mobile'=>$billing_mobile
                );
                echo json_encode(['res'=>'success','order_number'=>$order_id,'userData'=>$dataArr,'razorpay_key'=>$razorpay_key]); exit;
                }else{
                    echo json_encode(['res'=>'error','order_id'=>$order_id,'info'=>'Error with payment']); exit;
                }
            }else{
                echo json_encode(['res'=>'error']); exit;
            }

        }

    }

	public function success(){
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
        
        if(isset($_GET)){
            echo "<pre>";
            print_r($_GET);
            echo "</p>";
        }

        //echo view("custome_formnew_success", $data);
    }
    
    public function failure(){
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
        
        if(isset($_GET)){
            echo "<pre>";
            print_r($_GET);
            echo "</p>";
        }

        //echo view("custome_formnew_failure", $data);
    }



    
}
