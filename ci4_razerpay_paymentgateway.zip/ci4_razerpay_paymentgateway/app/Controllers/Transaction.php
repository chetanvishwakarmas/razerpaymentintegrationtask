<?php

namespace App\Controllers;

use App\Models\TransactionModel;

class Transaction extends BaseController
{
    public function index(): string
    {
    	$data['title'] = "Transaction ";
		$TransactionModel = new TransactionModel();
		$data['transactionList'] = $TransactionModel->findAll();
		
		//print_r($data['transactionList']);
		//die();

		return view('transaction', $data);
	}

}