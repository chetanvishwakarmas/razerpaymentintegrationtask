<?php

namespace App\Controllers;

class CheckoutSimple extends BaseController {

	public function __construct() {
		//$this->session 	= \Config\Services::session();
	}
    
	public function index() {
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
        $data = array();
        echo view("checkout_simple", $data);
	}
    
    public function paynow() {
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
    }
    
    public function success(){
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
        
        print_r($_REQUEST);
        
        echo view("simple_success", $data);
    }
    
    public function failure(){
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
        
        print_r($_REQUEST);
        
        echo view("simple_failure", $data);
    }
    
}
