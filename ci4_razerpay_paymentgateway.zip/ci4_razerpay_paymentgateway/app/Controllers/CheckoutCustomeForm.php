<?php

namespace App\Controllers;

class CheckoutCustomeForm extends BaseController {

	public function __construct() {
        //$this->session    = \Config\Services::session();
    }
    
    public function index() {
        error_reporting(E_ALL);
        ini_set('display_errors', '1');

        $data = array();
        echo view("checkout_custome_form", $data);
    }
    
    public function paynow(){
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
        
        //print_r($_POST);
        //die();
        
        $apiKey = "rzp_test_HSYmDqq745wqwZeXh48kg"; 
        $amount = $_POST['amount'];
        $name = $_POST['name'];
        $email = $_POST['email'];
        $mobile = $_POST['mobile'];
        
        $src = "https://checkout.razorpay.com/v1/checkout.js";
        $orderid = 'OID'.rand(10,100).'END';
        $dataAmount = $amount*100;
        $dataCurrency = "INR";
        $dataImage="https://example.com/your_logo.jpg";
        $dataThemeColor = "#F37254";
        $dataButtontext="Pay with Razorpay";
        $dataName="Test Data";
        $dataDescription="Testing details";
        
        echo "<script src=".$src." 
                    data-key=".$apiKey." 
                    data-amount=".$dataAmount." 
                    data-currency=".$dataCurrency."
                    data-id=".$orderid."
                    data-buttontext=".$dataButtontext."
                    data-name=".$dataName."
                    data-description=".$dataDescription."
                    data-image=".$dataImage."
                    data-prefill.name=".$name."
                    data-prefill.email=".$email."
                    data-prefill.contact=".$mobile."
                    data-theme.color=".$dataThemeColor." ></script>";
        
    }
    
    public function success(){
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
        
        print_r($_REQUEST);

        echo view("custome_form_success", $data);
    }
    
    public function failure(){
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
        
        print_r($_REQUEST);
        
        echo view("custome_form_failure", $data);
    }

}